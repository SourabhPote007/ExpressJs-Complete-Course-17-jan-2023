var express = require("express");
var app = express();

var cookieeparser = require('cookie-parser');
app.use(cookieeparser());

// app.get('/',function(req,res){
//     console.log('Cookies:',req.cookies);
//     res.cookie('name','Sourya Pote').send('Cookie set');
// });
app.get('/',function(req,res){
    // res.cookie('name','Sourabh Anil Pote',{expire:1000+Date.now()});
    res.cookie('name','Sourabh Anil Pote',{maxAge:1000});
    res.send('Cookie Set')
});
app.get('/clear',function(req,res){
    res.clearCookie('name');
    res.send('Cookie are cleared');
})
app.listen(3000);

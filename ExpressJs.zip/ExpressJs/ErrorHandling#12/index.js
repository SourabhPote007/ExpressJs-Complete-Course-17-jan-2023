const express = require("express");
var app = express();

app.get('/',function(req,res,next){    
    // res.send('calling');
    // res.status(404);
    // res.send('You Are Not Send Any Parameter For This URL')
    var err = new Error('Something went wrong');
    next(err);
});

app.get('*',function(req,res,next){
    // res.status(404);
    // res.send('This URL Not Found');
    next(err);
});
//Middleware
app.use(function(err, req, res, next){
    res.status(500);
    res.send('Oop, Something went wrong.');
})
app.listen(3000);
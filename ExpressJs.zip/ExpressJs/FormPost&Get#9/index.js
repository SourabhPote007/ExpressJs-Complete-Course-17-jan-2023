const express = require("express");
var app = express();
var bodyparser = require("body-parser");

app.use(bodyparser.json());
app.use(bodyparser.urlencoded({extended:true}));

app.set('view engine','pug');
app.set('views','./views');

app.get('/',function(req,res){
    res.render('form');
});
app.get('/get-data',function(req,res){
    res.send("name is:" +req.query.name+"email is:"+req.query.email);
});
app.post('/',function(req,res){
    // res.send("POST method is working");
    res.send("Name is"+req.body.name+" Email is:"+req.body.email);
});
app.listen(3000);

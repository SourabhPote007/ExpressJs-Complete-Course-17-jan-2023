const express = require("express");
var app = express();

app.get('/',function(req,res){
    res.send("This Url is get only Get Method request");
});
app.post('/',function(req,res){
    res.send("This Url is get only Post Method request");
});
app.put('/',function(req,res){
    res.send("This Url is get only Put Method request");
});
app.delete('/',function(req,res){
    res.send("This Url is get only Delete Method request");
});
app.listen(5000);
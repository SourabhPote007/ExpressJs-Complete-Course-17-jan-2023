const express = require('express');
var app = express();

app.use('/:age',function(req,res,next){
    if(req.params.age < 18)
    {
        res.redirect('/fail');
    }
    next();
})
app.get('/fail',function(req,res){
    res.send('your age is below -18');
})
app.get('/:age',function(req,res){
    res.send('your age is '+req.params.age);
})

app.listen(3000);
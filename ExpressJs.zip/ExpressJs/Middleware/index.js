const express = require("express");
var app = express();

app.get('/users',function(req,res){
    console.log("START");
    res.send("Got it")
    next();
});
app.use(function(req, res, next){
    console.log('A new Reuest Recived at'+Date.now());
    next();
});
app.get('/',function(req,res){
    console.log("END")
    res.send("End")
});
app.listen(3000);
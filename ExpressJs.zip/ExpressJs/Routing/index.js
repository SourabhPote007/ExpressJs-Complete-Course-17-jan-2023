const express = require("express");
var app = express();

app.get('/Route',function(req,res){
    res.send("Routing Using Express");
});
app.post('/form',function(req,res){
    res.send("Hi This is the Post Request get on server side..");
});
app.all('/hello',function(req,res){
    res.send("This url will gell all type of request.");
});
app.listen(4000);
const express = require("express");
var app = express();
var session = require('express-session');

app.use(session({secret:"My Secret here"}));

// app.get('/',function(req,res){
//     req.session.username = "Sourabh Pote";
//     res.send("Session are Set");
// });

// app.get('/get-session',function(req,res){
//     res.send("Youre Session Username is"+req.session.username);
// });
app.get('/',function(req,res){
    if(req.session.user_visit)
    {
        req.session.user_visit++;
        res.send("You Have Visited this page"+req.session.user_visit+"times.");
    }
    else
    {
        req.session.user_visit = 1;
        res.send("Hii youre visited this page First Time!");
    }
})
app.listen(3000);
const express = require("express");
var app = express();

app.set('view engine','pug');
app.set('views','./views');

app.get('/home',function(req,res){
    res.render('home',{
        name:"My home Page",
        user:{name:"Sourabh",age:"22"},
        url:"http//www.google.com"
    });
});
app.listen(3000);
const express = require("express");
var app = express();

app.get('/',function(req, res){
    res.send("Hello World");
});
// app.get('/:id',function(req,res){
//     res.send("ID is: "+req.params.id);
// });
app.get('/:id([0-9]{4})',function(req,res){
    res.send("ID is: "+req.params.id); 
});

app.get('/:id([a-z]{3})',function(req,res){
    res.send("ID is: "+req.params.id); 
});
app.get('/:id([a-z,0-9]{3})',function(req,res){
    res.send("ID is: "+req.params.id); 
});

app.get('/user/:name/:id',function(req,res){
    res.send("User name ID is:"+req.params.name+" & ID is :"+req.params.id)
});
//if url not found..
app.get('*',function(req,res){
    res.send("URL Not Found")
})
app.listen(3000);